import { Directive,ElementRef, Input, OnInit, HostListener} from '@angular/core';

@Directive({
  selector: '[appBColour]'
})
export class BColourDirective implements OnInit {
  @Input() customColour:string;
  @HostListener('mouseenter') onMouseEnter(){
    this.elementRef.nativeElement.style.fontSize="48px";
    //this.elementRef.nativeElement.style.color=this.customColour;
  }
  @HostListener('mouseleave') onMouseLeave(){
    this.elementRef.nativeElement.style.fontSize="24px";
  }
  constructor(public elementRef:ElementRef) {
    
   }
   ngOnInit()
   {
    if(this.customColour)
    {
      this.elementRef.nativeElement.style.backgroundColor=this.customColour;

    }
    else
    {
    this.elementRef.nativeElement.style.backgroundColor="blue";
    }

   }

}
