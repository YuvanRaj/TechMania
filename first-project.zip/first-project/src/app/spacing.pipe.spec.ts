import { SpacingPipe } from './spacing.pipe';

describe('SpacingPipe', () => {
  it('create an instance', () => {
    const pipe = new SpacingPipe();
    expect(pipe).toBeTruthy();
  });
});
