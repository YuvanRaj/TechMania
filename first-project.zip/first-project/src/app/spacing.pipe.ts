import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'spacing'
})
export class SpacingPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    var str=value.charAt(0)+" ";
    str+=value.substring(1);
    
    return str;
  }

}
