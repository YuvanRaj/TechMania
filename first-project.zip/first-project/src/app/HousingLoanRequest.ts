export class HousingLoanRequest {
    
    constructor(public principle:number,public interest:number,public year:number)
    {

    }

}