import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeComponent } from '../employee/employee.component';
import { Employee } from '../employee';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input() salaryToBeModified:number;
@Input() deptIdToBeModified:string;
@Input() empNameToBeModified:string;
@Input() empId:number;
@Output() sendDataToParent =new EventEmitter<Employee>();
updatedSalary;
updatedDeptId;
updatedEmpName;
  constructor() { 
   
  }

  ngOnInit() {
    console.log(this.salaryToBeModified);
    this.updatedSalary=this.salaryToBeModified;
    this.updatedEmpName=this.empNameToBeModified;
    this.updatedDeptId=this.deptIdToBeModified;
  }
  savebuttonEventHandler()
  {
    console.log("save button clicked");
    var tempObj=new Employee(this.empId,this.updatedEmpName,this.updatedSalary,this.updatedDeptId);
    this.sendDataToParent.emit(tempObj);
  }

}
