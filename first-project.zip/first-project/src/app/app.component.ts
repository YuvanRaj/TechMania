import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'first-project123';
  flag:boolean=true;
  ctr:number=198798.6778698798;
  today=new Date(2020,1,11);
  firstName:string="";
  lastName:string="";
  colours=["red","green","blue"];
  emp={
    empId:101,empName:"Reena Seshadri"
  }

  companyName:string="CITI";
  empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1",
  gender:"f",imageUrl:"../assets/waterfalls.jpg"},
  {empId:102,empName:"Gaurav",salary:2000,deptId:"D1",gender:"m"},
  {empId:103,empName:"Karan",salary:2000,deptId:"D2",gender:"m"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1",gender:"m"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2",gender:"m"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3",gender:"m"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3",gender:"m"}]

myFunc(p1)
{
  alert("Button clicked" +p1);
}
changeNameEventHandler(event)
{
  this.firstName=event.target.value;
}

}
