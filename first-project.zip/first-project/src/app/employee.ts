export class Employee {
    
    constructor(public empId:number,public empName:string,public salary:number,public deptId:string)
    {

    }

}
