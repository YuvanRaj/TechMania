import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import {Router} from "@angular/router";
import { TalkWithServerService } from '../talk-with-server.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
empArr:Employee[];
showLoading:boolean;
showEmployees:boolean;
empToBeUpdated:Employee;
  constructor(public router:Router,public myService:TalkWithServerService) { 
    this.empArr=new Array(10);
    this.showEmployees=false;
    this.showLoading=true;
  }

  ngOnInit() {
   /*  var n1=setInterval(()=>{
      this.empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
    {empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
    {empId:103,empName:"Karan",salary:2000,deptId:"D2"},
    {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
    {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
    {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
    {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}];
    this.showLoading=false;
    clearInterval(n1);

    },5000)
 */    
    this.myService.getAllEmployees()
    .subscribe((data)=>{
        console.log(data);
        this.empArr=data as Employee[];
        this.showLoading=false;

    });

    
  }
  deleteEmpEventHandler(p1:number)
  {
   /*  var pos=this.empArr.findIndex(emp=>emp.empId==p1);
    this.empArr.splice(pos,1);
 */
    this.myService.deleteEmployee(p1).subscribe((data)=>{
      console.log(data);
      var res:Response=data as Response;
      if(!res)
      {
        alert("Deletion successful");
        this.myService.getAllEmployees()
        .subscribe((data)=>{
            console.log(data);
            this.empArr=data as Employee[];
            
        });

      }
 
    });

  }
  editEventClickHandler(p1:Employee)
  {
    this.showEmployees=true;
    this.empToBeUpdated=p1;
  }
  sendDataToParentEventHandler(p1)
  {
    console.log(p1);
    // var pos=this.empArr.findIndex(emp=>emp.empId==p1.empId);
    // this.empArr.splice(pos,1,p1);
    this.myService.updateEmployee(p1)
    .subscribe((data)=>{
      console.log(data);
      this.myService.getAllEmployees()
      .subscribe((data)=>{
        console.log(data);
        this.empArr=data as Employee[];
        
    });

    })
    this.showEmployees=false;
  }
  addNewEmployeeEventHandler()
  {
    this.router.navigate(["/addEmployee"]);
  }
}
