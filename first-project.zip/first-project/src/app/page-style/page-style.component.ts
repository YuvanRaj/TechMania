import { Component, OnInit } from '@angular/core';
import { HousingLoanRequest } from '../HousingLoanRequest';
import { HousingloanService } from '../housingloan.service';

@Component({
  selector: 'app-page-style',
  templateUrl: './page-style.component.html',
  styleUrls: ['./page-style.component.css']
})
export class PageStyleComponent implements OnInit {
  principle:number;
  interestRate:number;
  year:number;

  constructor(public housingloanservice:HousingloanService) {}

  savebuttonEventHandler()
  {
    console.log("save button clicked");
    var p1=new HousingLoanRequest(this.principle,this.interestRate,this.year);

    alert(this.principle);

    this.housingloanservice.calculateEmi(p1)
    .subscribe((data)=>{
      console.log(data);
    });
  }

  items = [
    { value: "0", view: "zero" },
    { value: "1", view: "one" },
    { value: "2", view: "Two" }
  ];

  columnDefs = [
    {field: 'make' ,sortable: true},
    {field: 'model',sortable: true },
    {field: 'price',sortable: true}
];

rowData = [
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 }
];

  

  ngOnInit() {
  }

  
}
