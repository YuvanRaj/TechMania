import { TestBed } from '@angular/core/testing';

import { TalkWithServerService } from './talk-with-server.service';

describe('TalkWithServerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TalkWithServerService = TestBed.get(TalkWithServerService);
    expect(service).toBeTruthy();
  });
});
