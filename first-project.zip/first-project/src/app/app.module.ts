import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {TalkWithServerService} from "./talk-with-server.service";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SpacingPipe } from './spacing.pipe';

import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";

import { HomeComponent } from './home/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { Page404Component } from './page404/page404.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { AddNewEmployeeComponent } from './add-new-employee/add-new-employee.component';
import { DetailsComponent } from './details/details.component';
import { BColourDirective } from './b-colour.directive';
import { CcImgDirective } from './cc-img.directive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule, MatButtonModule, MatSelectModule, MatIconModule,MatRadioModule} from '@angular/material';
import { MatSliderModule } from '@angular/material/slider';
import { PageStyleComponent } from './page-style/page-style.component';
import { AgGridModule } from 'ag-grid-angular';
import { HousingloanService } from './housingloan.service';

 @NgModule({
  declarations: [
    AppComponent,
    SpacingPipe,
    HomeComponent,
    EmployeeComponent,
    Page404Component,
    ParentComponent,
    ChildComponent,
    AddNewEmployeeComponent,
    DetailsComponent,
    BColourDirective,
    CcImgDirective,
    PageStyleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule, BrowserAnimationsModule,MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatIconModule,
    MatSliderModule,
    MatRadioModule,
    AgGridModule.withComponents([])
  ],
  providers: [TalkWithServerService,HousingloanService],
  bootstrap: [HomeComponent]
})
export class AppModule { }
