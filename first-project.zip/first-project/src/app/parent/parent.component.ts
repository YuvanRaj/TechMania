import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
empObj:Employee;
showChild:boolean;
  constructor() {
    this.empObj=new Employee(101,"Tara",7687,"D1");
    this.showChild=false;
   }

  ngOnInit() {
  }
  editEventHandler()
  {
    this.showChild=true;

  }
  sendDataToParentEventHandler(p1)
  {
    this.empObj=p1;
    this.showChild=false;

  }
}
