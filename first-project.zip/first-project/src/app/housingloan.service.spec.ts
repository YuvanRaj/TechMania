import { TestBed } from '@angular/core/testing';

import { HousingloanService } from './housingloan.service';

describe('HousingloanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HousingloanService = TestBed.get(HousingloanService);
    expect(service).toBeTruthy();
  });
});
