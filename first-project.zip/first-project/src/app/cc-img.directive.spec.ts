import { CcImgDirective } from './cc-img.directive';

describe('CcImgDirective', () => {
  it('should create an instance', () => {
    const directive = new CcImgDirective();
    expect(directive).toBeTruthy();
  });
});
