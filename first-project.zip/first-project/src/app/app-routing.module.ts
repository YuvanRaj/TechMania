import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { Page404Component } from './page404/page404.component';
import { ParentComponent } from './parent/parent.component';
import { AddNewEmployeeComponent } from './add-new-employee/add-new-employee.component';
import { DetailsComponent } from './details/details.component';
import { PageStyleComponent } from './page-style/page-style.component';


const routes: Routes = [
  {path:"app",component:AppComponent},
  {path:"employees",component:EmployeeComponent},
  {path:"home",component:AppComponent},
  {path:"parent",component:ParentComponent},
  {path:"addEmployee",component:AddNewEmployeeComponent},
  {path:"details/:empId",component:DetailsComponent},
  {path:"pagestyle",component:PageStyleComponent},
  {path:"",redirectTo:"/app",pathMatch:"full"},
  {path:"**", component:Page404Component},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
