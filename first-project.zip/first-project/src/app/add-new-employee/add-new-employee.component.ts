import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { TalkWithServerService } from '../talk-with-server.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-new-employee',
  templateUrl: './add-new-employee.component.html',
  styleUrls: ['./add-new-employee.component.css']
})
export class AddNewEmployeeComponent implements OnInit {
empObj:Employee=new Employee(0,"",0,"");
  constructor(public myService:TalkWithServerService,public router:Router) { }

  ngOnInit() {
  }
  addEmpEventHandler()
  {
    console.log(this.empObj);
    this.myService.addNewEmployee(this.empObj)
    .subscribe((data)=>{
      console.log(data);
      this.router.navigate(["/employees"]);

    })

  }
}
