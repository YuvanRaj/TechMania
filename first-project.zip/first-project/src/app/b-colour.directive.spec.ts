import { BColourDirective } from './b-colour.directive';

describe('BColourDirective', () => {
  it('should create an instance', () => {
    const directive = new BColourDirective();
    expect(directive).toBeTruthy();
  });
});
