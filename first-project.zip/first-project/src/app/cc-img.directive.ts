import { Directive, OnInit, Input, OnChanges, HostBinding } from '@angular/core';

@Directive({
  selector: '[appCcImg]'
})
export class CcImgDirective implements OnInit,OnChanges {
  @Input() ccnumber;
  @HostBinding("src") imageSrc;
 
  constructor() { }
  ngOnInit()
  {

  }
  ngOnChanges()
  {
    if(this.ccnumber)
    {
      if(this.ccnumber.startsWith("1"))
      {
        this.imageSrc="./assets/amex.png";
      }
      if(this.ccnumber.startsWith("2"))
      {
        this.imageSrc="./assets/visa.png";
      }
      if(this.ccnumber.startsWith("3"))
      {
        this.imageSrc="./assets/mastercard.png";
      }
    }

  }

}
