import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import { HousingLoanRequest } from './HousingLoanRequest';

@Injectable()
export class HousingloanService {
  serverUrl;
  constructor(public httpClient:HttpClient) {

  }

  calculateEmi(p1:HousingLoanRequest)
  {
    
    const httpOptions = {
      headers: new HttpHeaders({})
    };

    httpOptions.headers.append('Access-Control-Allow-Headers','X-Requested-With,content-type');
    httpOptions.headers.append('Access-Control-Allow-Methods','GET, POST, OPTIONS, PUT, PATCH, DELETE');
    httpOptions.headers.append('Access-Control-Allow-Origin','http://localhost:4200');    
    httpOptions.headers.append('Access-Control-Allow-Credentials', 'true');
    

    this.serverUrl="http://localhost:8080/MyAngularApp/services/housingloan/getHousingLoanInfo";
    alert(' i am in');
    alert(httpOptions);
    return this.httpClient.post(this.serverUrl,p1,httpOptions);
  }

}
