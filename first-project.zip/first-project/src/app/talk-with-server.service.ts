import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Employee } from './employee';
@Injectable()
export class TalkWithServerService {
 serverUrl;
  constructor(public httpClient:HttpClient) { }
  getAllEmployees()
  {
    this.serverUrl="http://localhost:3000/employees";
    return this.httpClient.get(this.serverUrl);
  }
  deleteEmployee(p1:number)
  {
    this.serverUrl="http://localhost:3000/employees/"+p1;
    return this.httpClient.delete(this.serverUrl);
    
  }
  updateEmployee(p1:Employee)
  {
    this.serverUrl="http://localhost:3000/employees";
    return this.httpClient.put(this.serverUrl,p1);

  }
  addNewEmployee(p1:Employee)
  {
    this.serverUrl="http://localhost:3000/employees";
    return this.httpClient.post(this.serverUrl,p1);

  }
}
