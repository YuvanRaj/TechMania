var mongoClient=require("mongodb").MongoClient;
const connString="mongodb+srv://anju:anju@cluster0-vrtxz.mongodb.net/test?retryWrites=true&w=majority";
mongoClient.connect(connString,(err,client)=>{
    if(!err)
    {
        console.log("Successfully connected to the db");
        var db=client.db("citiDb");
        db.collection("employees",(err,coll)=>{
            if(!err)
            {
                coll.insertOne({"empId":101,"empName":"Asha","salary":1001,"deptId":"D1"},(err,data)=>{
                    if(!err)
                    {
                        console.log("Document inserted successfully");
                    }
                })
            }
        })
    }
})